=== Selzy ===
Tags: selzy, subscribe
Donate link: https://selzy.com/ua/
Tested up to: 7.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The plugin allows you to create a subscription form on your website and send user data to Selzy.

== Description ==
The plugin allows you to create a subscription form on your website and send user data to Selzy.

All data of your subscribers will be sent to your account in Selzy.

== Installation ==
1. Install the plugin in wordpress.
2. Generate Selzy API key: https://www.selzy.com/ua/support/api/common/api-key/.
3. Create new subscription form.
4. Configure the subscription field.
5. Connect it to Selzy.

== Screenshots ==
1. Settings
2. Form list
3. Form settings

== Changelog ==
There are no changes in the operation of the application. The plugin works stably.

== Upgrade Notice ==
The latest version of the plugin works on the latest versions of wordpress.